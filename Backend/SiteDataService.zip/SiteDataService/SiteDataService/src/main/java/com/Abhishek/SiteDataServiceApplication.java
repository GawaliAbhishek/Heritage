package com.Abhishek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteDataServiceApplication.class, args);
	}

}
