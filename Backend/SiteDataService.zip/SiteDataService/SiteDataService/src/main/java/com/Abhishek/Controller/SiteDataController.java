package com.Abhishek.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Abhishek.Model.Sitedata;
import com.Abhishek.Service.SiteDataService;

@RestController
@RequestMapping("/sitedata")
public class SiteDataController {

	@Autowired
	private SiteDataService service;
	
	public Sitedata search(String name) {
		return service.searchByName(name);
	}
}
